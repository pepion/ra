package com.vinsguru.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GRPCAPIDemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(GRPCAPIDemoApplication.class, args);
    }

}