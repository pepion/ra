package com.vinsguru.reactivemongo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReactiveMongoApplicationTests {

	@Test
	void contextLoads() {
	}

}
