package com.vinsguru.model;

import java.io.Serializable;

public enum Priority implements Serializable {
    LOW,
    HIGH,
    URGENT
}
