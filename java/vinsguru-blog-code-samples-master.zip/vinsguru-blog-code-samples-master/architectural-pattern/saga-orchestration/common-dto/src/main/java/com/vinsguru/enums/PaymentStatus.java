package com.vinsguru.enums;

public enum  PaymentStatus {
    PAYMENT_APPROVED,
    PAYMENT_REJECTED;
}
