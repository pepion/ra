package com.vinsguru.events.inventory;

public enum InventoryStatus {
    RESERVED,
    REJECTED;
}
