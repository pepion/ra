package com.vinsguru.cacheaside;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CacheAsideApplicationTests {

	@Test
	void contextLoads() {
	}

}
